var fs = require('fs');

describe('Protractor Demo App', function () {
    var results = [],
        url = 'http://localhost:8080/ejemplo/',
        numberOfItems = element(by.id('itemsLength')),
        numberOfWatchers = element(by.id('numberOfWatchers')),
        renderDuration = element(by.id('renderDuration')),
        testButton = element(by.buttonText('test'));

    beforeEach(function () {
        browser.get(url);
    });

    it('test with 10000 items', function () {
        numberOfItems.clear().then(function () {
            numberOfItems.sendKeys(10000);
            testButton.click();
        });

        numberOfWatchers.getText().then(function (numWatches) {
            renderDuration.getText().then(function (render) {
                results.push('items, 10000, rendering, ' + render + ', watchers, ' + numWatches);
            });
        });
    });

    it('should print result', function () {
        var log = '';
        for (var i = 0; i < results.length; i++) {
            log += results[i] + '\n';
        }
        fs.appendFile('results.csv', log, function (err) {
            if (err) {
                console.log(err);
            }
        });
    });


});
